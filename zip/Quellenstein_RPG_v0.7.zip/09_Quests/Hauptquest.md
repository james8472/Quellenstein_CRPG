Vermisste Holzfaeller -> Tempel.
