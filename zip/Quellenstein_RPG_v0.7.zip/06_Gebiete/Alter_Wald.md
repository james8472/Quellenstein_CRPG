Hauptgebiet.
