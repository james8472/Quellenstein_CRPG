Godot Szenenstruktur.
