Normal, Selten, Episch, Relikt.
