Erkenntnismagier.
