Konfrontation mit Arzakar.
