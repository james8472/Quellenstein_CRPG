Abstieg in den Untertempel.
