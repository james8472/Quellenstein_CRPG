Niedere Daemonen und Schattenwesen.
