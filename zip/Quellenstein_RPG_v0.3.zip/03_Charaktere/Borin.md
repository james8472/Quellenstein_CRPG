Erkenntnismagier fuer Raetsel.
