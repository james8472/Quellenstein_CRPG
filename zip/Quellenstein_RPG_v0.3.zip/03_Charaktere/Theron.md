Heiler. Schutzzauber.
