Herrschaftsmagier fuer Kontrolle.
