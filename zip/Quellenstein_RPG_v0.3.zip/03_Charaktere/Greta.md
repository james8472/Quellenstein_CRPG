Tank. Schildwall. Frontlinie.
