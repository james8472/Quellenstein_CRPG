Buffs und Dialoge.
