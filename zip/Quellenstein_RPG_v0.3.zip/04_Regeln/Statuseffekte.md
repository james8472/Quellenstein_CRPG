Brennen, Einfrieren, Angst, Benommen.
