Einstieg, Fallen und Bibliothek.
