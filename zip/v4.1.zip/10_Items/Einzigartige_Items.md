Legendäre Tempelartefakte.
