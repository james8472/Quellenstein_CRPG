Qualitaeten und Seltenheiten.
