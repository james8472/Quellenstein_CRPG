Questflow der Hauptstory.
