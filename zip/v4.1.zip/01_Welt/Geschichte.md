Arzakar wurde vor Jahrhunderten versiegelt.
