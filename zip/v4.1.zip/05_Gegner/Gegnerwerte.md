Vorlage fuer Datenwerte.
