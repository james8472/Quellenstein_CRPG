20 Gegnerkonzepte.
