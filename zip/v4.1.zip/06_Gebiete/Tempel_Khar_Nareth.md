Dungeonstruktur.
