Open Area.
