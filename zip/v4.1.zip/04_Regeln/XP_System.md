Level 1-10.
