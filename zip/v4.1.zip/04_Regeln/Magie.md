Mana, Glaubenskraft, Zauberschulen.
