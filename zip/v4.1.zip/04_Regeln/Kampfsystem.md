RTwP, Aggro, Pause, Formationen.
