Finale gegen Arzakar.
