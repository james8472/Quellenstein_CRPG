Ruinen von Khar-Nareth.
