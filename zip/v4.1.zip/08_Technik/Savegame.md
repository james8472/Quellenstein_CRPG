JSON Savegame Konzept.
