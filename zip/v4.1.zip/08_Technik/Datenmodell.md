NPC, Gegner, Item, Skill Ressourcen.
