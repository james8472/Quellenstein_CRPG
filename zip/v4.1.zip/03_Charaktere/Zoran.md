Kontrollmagie und Debuffs.
