Erkenntnismagier und Raetsel.
