Heilung und Schutzzauber.
