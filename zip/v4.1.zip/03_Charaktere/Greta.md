Tank Build, Skillpfad Schildwall.
