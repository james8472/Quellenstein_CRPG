GDD v0.4
Vertical Slice als Ziel.
