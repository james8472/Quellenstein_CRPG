5 Helden, Echtzeit mit Pause, Max Level 10.
