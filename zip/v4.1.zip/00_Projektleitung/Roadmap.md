v0.4 Design Freeze
v0.5 Vertical Slice
v0.6 Alpha
